# App — Android WebView APK

This Android project loads the live chat website at `https://vijendarverma.in/chat/`.

## Branding update
- Application name: **App**
- Launcher icon: supplied image converted into high-resolution PNG launcher assets and Android adaptive icon assets.
- Splash screen: the same supplied image is shown centered with `fitCenter`, so the complete image remains visible without top/bottom/left/right cropping.

## Build with GitHub Actions
Upload `Android.zip` and `Android.yml` to the repository root, then run the **Build Android APK** workflow.
